#pragma once
#include "AActor.h"
class AUIActor : public AActor
{
public:
	AUIActor() = default;
	virtual ~AUIActor() = default;
};

