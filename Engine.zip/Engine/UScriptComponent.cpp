#include "pch.h"
#include "UScriptComponent.h"

void UScriptComponent::Init()
{
}

void UScriptComponent::Tick()
{
}

void UScriptComponent::Render()
{
}

void UScriptComponent::Destroy()
{
}
